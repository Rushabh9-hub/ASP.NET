﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;

namespace Connectivity
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        public static SqlConnection cn = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Rushabh\Connectivity\Connectivity\App_Data\Database1.mdf;Integrated Security=True;User Instance=True");
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void button_Click(object sender, EventArgs e)
        {
            String sql = "insert into Con_tab values('" + unm.Text + "','" + pwd.Text + "')";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            int a = da.Fill(dt);
            unm.Text = pwd.Text = String.Empty;
            display();
        }

        protected void display()
        {
            String sql = "select * from Con_tab";
            SqlDataAdapter da = new SqlDataAdapter(sql, cn);
            DataTable dt = new DataTable();
            int a = da.Fill(dt);

            GridView1.DataSource = dt;
            GridView1.DataBind();

            unm.Text = pwd.Text = String.Empty;
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            display();
        }
    }
}